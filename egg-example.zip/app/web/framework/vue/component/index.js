import Vue from 'vue';

import Layout from 'component/layout/standard';

Vue.component(Layout.name, Layout);
