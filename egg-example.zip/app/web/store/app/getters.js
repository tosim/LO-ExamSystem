'use strict';


const getters = {

};

export default getters;