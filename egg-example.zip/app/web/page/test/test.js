import App from 'app';
import Test from './test.vue';
export default App.init({
  ...Test
});
