<template>
  <layout>
    <img src="../../asset/images/logo.png" />
  {{message}}
  </layout>
</template>
<style>
  @import "about.css";
</style>
<script type="text/babel">

  export default {
    components: {

    },
    computed: {

    },
    methods: {

    },
    mounted() {

    }
  }
</script>

