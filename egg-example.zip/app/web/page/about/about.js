import App from 'app';
import About from './about.vue';
export default App.init({
  ...About
});
