<template>
  <layout>
  {{message}}
  </layout>
</template>
<style>
  @import "router.css";
</style>
<script type="text/babel">

  export default {
    components: {

    },
    computed: {

    },
    methods: {

    },
    mounted() {

    }
  }
</script>

