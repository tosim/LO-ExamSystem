import App from 'app';
import Index from './index.vue';
export default App.init({
  ...Index
});
