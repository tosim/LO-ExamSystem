<template>
  <app-layout>
    <transition name="fade" mode="out-in">
      <p>nihao</p>
      <router-view></router-view>
    </transition>
  </app-layout>
</template>
<style lang="scss">

</style>
<script type="text/babel">
  export default {
    computed: {

    },
    mounted(){

    }
  }
</script>
