exports.static = true;

exports.vue = {
  enable: true,
  package: 'egg-view-vue'
};

exports.vuessr = {
  enable: true,
  package: 'egg-view-vue-ssr'
};
